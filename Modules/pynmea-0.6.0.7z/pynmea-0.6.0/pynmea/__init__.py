__VERSION__ =  (0, 6, 0)
def get_version():
    return '.'.join([str(x) for x in __VERSION__])
